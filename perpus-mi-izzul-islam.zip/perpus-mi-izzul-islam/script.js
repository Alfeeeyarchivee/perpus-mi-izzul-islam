// =========================================================================
// TEMPELKAN URL WEB APP GOOGLE APPS SCRIPT ANDA DI BARIS INI:
// =========================================================================
const CLOUD_API_URL = ""; 

let books = JSON.parse(localStorage.getItem("mi_books_sync_v4")) || [];
let visits = JSON.parse(localStorage.getItem("mi_visits_sync_v4")) || [];
let literacyNotes = JSON.parse(localStorage.getItem("mi_literacy_sync_v4")) || [];

let currentUser = null;
let currentCategory = "Semua";
let activeBook = null;
let uploadedCoverBase64 = "";
let uploadedPdfBase64 = "";
let currentBlobUrl = null;

// ================= FUNGSI IKON MATA (INTIP / SEMBUNYIKAN PASSWORD ADMIN) =================
function toggleAdminPassword() {
    const passInput = document.getElementById("admin-password");
    const eyeOpen = document.getElementById("eye-open");
    const eyeClosed = document.getElementById("eye-closed");

    if (passInput.type === "password") {
        passInput.type = "text";
        eyeOpen.classList.add("hidden");
        eyeClosed.classList.remove("hidden");
    } else {
        passInput.type = "password";
        eyeOpen.classList.remove("hidden");
        eyeClosed.classList.add("hidden");
    }
}

// ================= KOMPRESI GAMBAR SAMPUL OTOMATIS =================
const coverInput = document.getElementById("book-cover-file");
if (coverInput) {
    coverInput.addEventListener("change", function(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(event) {
            const img = new Image();
            img.onload = function() {
                const canvas = document.createElement("canvas");
                const maxWidth = 340;
                const scale = maxWidth / img.width;
                canvas.width = maxWidth;
                canvas.height = img.height * scale;

                const ctx = canvas.getContext("2d");
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                uploadedCoverBase64 = canvas.toDataURL("image/jpeg", 0.72);

                const preview = document.getElementById("cover-preview");
                preview.src = uploadedCoverBase64;
                preview.classList.remove("hidden");
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(file);
    });
}

// Baca File PDF saat Admin memilih file PDF dari perangkat
const pdfInput = document.getElementById("book-pdf-file");
if (pdfInput) {
    pdfInput.addEventListener("change", function(e) {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function(event) {
            uploadedPdfBase64 = event.target.result;
        };
        reader.readAsDataURL(file);
    });
}

// ================= SINKRONISASI REAL-TIME LINTAS SEMUA PERANGKAT =================
async function syncFromCloud() {
    if (!CLOUD_API_URL) {
        updateCounters();
        return;
    }
    try {
        const res = await fetch(CLOUD_API_URL + "?t=" + Date.now());
        const data = await res.json();
        if (data.books && Array.isArray(data.books)) {
            books = data.books;
            localStorage.setItem("mi_books_sync_v4", JSON.stringify(books));
            renderBooks();
            renderAdminTables();
        }
        if (data.literacy && Array.isArray(data.literacy)) {
            literacyNotes = data.literacy;
            localStorage.setItem("mi_literacy_sync_v4", JSON.stringify(literacyNotes));
        }
        if (data.visits && Array.isArray(data.visits)) {
            visits = data.visits;
            localStorage.setItem("mi_visits_sync_v4", JSON.stringify(visits));
        }
        updateCounters();
    } catch (err) {
        console.log("Menyinkronkan data...");
    }
}

async function forceSyncNow() {
    const badge = document.getElementById("admin-sync-status");
    if (badge) badge.textContent = "↻ Sedang Menyinkronkan...";
    await syncFromCloud();
    if (badge) badge.textContent = "● Sinkronisasi Otomatis Aktif";
}

setInterval(syncFromCloud, 10000);

function updateCounters() {
    const studentBadge = document.getElementById("book-count-badge");
    if (studentBadge) studentBadge.textContent = `${books.length} Buku Tersedia`;
    const adminTotal = document.getElementById("admin-total-books");
    if (adminTotal) adminTotal.textContent = books.length;
}

function saveLocalData() {
    try {
        localStorage.setItem("mi_books_sync_v4", JSON.stringify(books));
        localStorage.setItem("mi_visits_sync_v4", JSON.stringify(visits));
        localStorage.setItem("mi_literacy_sync_v4", JSON.stringify(literacyNotes));
    } catch (e) {
        alert("Memori browser penuh untuk PDF besar. Gunakan link Google Drive PDF atau pasang CLOUD_API_URL.");
    }
    updateCounters();
}

// ================= NAVIGASI & LOGIN =================
function switchView(viewId) {
    document.querySelectorAll(".view").forEach(v => v.classList.add("hidden"));
    const target = document.getElementById(viewId);
    if (target) target.classList.remove("hidden");
    stopSpeech();
}

function backToHome() {
    currentUser = null;
    switchView("home-view");
}

// Login Siswa / Guru
document.getElementById("student-login-form").addEventListener("submit", function(e) {
    e.preventDefault();
    const name = document.getElementById("user-name").value.trim();
    const userClass = document.getElementById("user-class").value;
    
    if (!name || !userClass) {
        alert("Mohon isi Nama Lengkap dan pilih Kelas terlebih dahulu.");
        return;
    }

    currentUser = { name, userClass };
    document.getElementById("welcome-user").textContent = `${name} (${userClass})`;
    
    const newVisit = {
        time: new Date().toLocaleString("id-ID"),
        name: name,
        userClass: userClass,
        activity: "Masuk Perpustakaan"
    };
    visits.unshift(newVisit);
    saveLocalData();

    renderBooks();
    switchView("student-view");

    if (CLOUD_API_URL) {
        fetch(CLOUD_API_URL, {
            method: "POST",
            body: JSON.stringify({ action: "addVisit", visit: newVisit })
        }).catch(() => {});
        syncFromCloud();
    }
});

// Login Admin
document.getElementById("admin-login-form").addEventListener("submit", function(e) {
    e.preventDefault();
    const passInput = document.getElementById("admin-password");
    const pass = passInput.value.trim();
    
    if (pass === "adminperpusMI123") {
        passInput.value = "";
        passInput.type = "password";
        document.getElementById("eye-open").classList.remove("hidden");
        document.getElementById("eye-closed").classList.add("hidden");

        renderAdminTables();
        switchView("admin-view");
        syncFromCloud();
    } else {
        alert("Password Admin salah! Silakan klik ikon mata untuk mengecek ketikan Anda.");
    }
});

// ================= KATALOG BUKU SISWA =================
function setCategory(cat, btn) {
    currentCategory = cat;
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    renderBooks();
}

function filterBooks() {
    renderBooks();
}

function renderBooks() {
    const grid = document.getElementById("book-grid");
    const keyword = document.getElementById("search-input").value.toLowerCase();
    grid.innerHTML = "";
    updateCounters();

    const filtered = books.filter(b => {
        const matchCat = currentCategory === "Semua" || b.category === currentCategory;
        const matchText = b.title.toLowerCase().includes(keyword) || 
                          b.author.toLowerCase().includes(keyword) ||
                          b.summary.toLowerCase().includes(keyword);
        return matchCat && matchText;
    });

    if (filtered.length === 0) {
        grid.innerHTML = `<p style="grid-column: 1/-1; text-align:center; color:#475569; padding:30px;">
            Belum ada buku di kategori ini. Silakan Admin menambahkan buku atau menghubungkan Google Drive.
        </p>`;
        return;
    }

    filtered.forEach(book => {
        const coverHTML = book.cover 
            ? `<img src="${book.cover}" alt="Sampul ${book.title}">`
            : `<svg width="68" height="68" viewBox="0 0 24 24" fill="none" stroke="#1B7A43" stroke-width="1.8">
                 <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                 <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
               </svg>`;

        const card = document.createElement("div");
        card.className = "book-card";
        card.onclick = () => openBookModal(book.id);
        card.innerHTML = `
            <div class="book-cover">
                <span class="book-cat-tag">${book.category}</span>
                ${coverHTML}
            </div>
            <div class="book-info">
                <h3>${book.title}</h3>
                <div class="book-author">Pengarang: ${book.author}</div>
                <p class="book-summary-preview">${book.summary}</p>
                <span class="read-prompt">Baca Buku PDF Sekarang</span>
            </div>
        `;
        grid.appendChild(card);
    });
}

// ================= KONVERSI BASE64 KE BLOB URL AGAR PDF 100% TAMPIL =================
function base64ToBlobUrl(base64Data) {
    try {
        const parts = base64Data.split(";base64,");
        const contentType = parts[0].split(":")[1] || "application/pdf";
        const raw = window.atob(parts[1]);
        const rawLength = raw.length;
        const uInt8Array = new Uint8Array(rawLength);
        for (let i = 0; i < rawLength; ++i) {
            uInt8Array[i] = raw.charCodeAt(i);
        }
        const blob = new Blob([uInt8Array], { type: contentType });
        return URL.createObjectURL(blob);
    } catch (e) {
        return base64Data;
    }
}

function extractDriveFileId(input) {
    if (!input) return "";
    if (!input.startsWith("http") && !input.startsWith("data:")) return input.trim();
    const match1 = input.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    if (match1 && match1[1]) return match1[1];
    const match2 = input.match(/[?&]id=([a-zA-Z0-9_-]+)/);
    if (match2 && match2[1]) return match2[1];
    return "";
}

function openBookModal(bookId) {
    activeBook = books.find(b => b.id === bookId);
    if (!activeBook) return;

    document.getElementById("modal-category").textContent = activeBook.category;
    document.getElementById("modal-title").textContent = activeBook.title;
    document.getElementById("modal-author").textContent = "Pengarang: " + activeBook.author;
    document.getElementById("modal-summary").textContent = activeBook.summary;

    const readerContainer = document.getElementById("pdf-reader-container");
    readerContainer.innerHTML = "";

    // Bersihkan Blob URL lama jika ada
    if (currentBlobUrl) {
        URL.revokeObjectURL(currentBlobUrl);
        currentBlobUrl = null;
    }

    const fileId = extractDriveFileId(activeBook.pdfId || activeBook.pdfSource);

    if (fileId) {
        // Tampilkan PDF Google Drive langsung di layar pembaca
        readerContainer.innerHTML = `<iframe src="https://drive.google.com/file/d/${fileId}/preview" width="100%" height="100%" style="border:none;" allow="autoplay"></iframe>`;
    } else if (activeBook.pdfBase64) {
        // Ubah PDF upload perangkat menjadi Blob URL agar tidak diblokir Chrome/Edge
        currentBlobUrl = base64ToBlobUrl(activeBook.pdfBase64);
        readerContainer.innerHTML = `<embed src="${currentBlobUrl}#toolbar=1&navpanes=0" type="application/pdf" width="100%" height="100%">`;
    } else {
        readerContainer.innerHTML = `<div style="padding:30px; text-align:center; color:#475569;">
            <p><strong>File PDF tidak ditemukan.</strong></p>
            <p style="font-size:0.88rem; margin-top:6px;">Pastikan Admin telah memilih file PDF atau memasukkan link file PDF Google Drive yang benar.</p>
        </div>`;
    }

    const gformBtn = document.getElementById("gform-download-btn");
    if (activeBook.gformUrl) {
        gformBtn.href = activeBook.gformUrl;
        gformBtn.classList.remove("hidden");
    } else if (fileId) {
        gformBtn.href = `https://drive.google.com/uc?export=download&id=${fileId}`;
        gformBtn.classList.remove("hidden");
    } else if (currentBlobUrl) {
        gformBtn.href = currentBlobUrl;
        gformBtn.setAttribute("download", activeBook.title + ".pdf");
        gformBtn.classList.remove("hidden");
    } else {
        gformBtn.classList.add("hidden");
    }

    document.getElementById("literacy-note").value = "";
    document.getElementById("literacy-status").textContent = "";

    if (currentUser) {
        const visitLog = {
            time: new Date().toLocaleString("id-ID"),
            name: currentUser.name,
            userClass: currentUser.userClass,
            activity: `Membaca PDF: ${activeBook.title}`
        };
        visits.unshift(visitLog);
        saveLocalData();
        if (CLOUD_API_URL) {
            fetch(CLOUD_API_URL, {
                method: "POST",
                body: JSON.stringify({ action: "addVisit", visit: visitLog })
            }).catch(() => {});
        }
    }

    document.getElementById("book-modal").classList.remove("hidden");
}

function closeBookModal() {
    document.getElementById("book-modal").classList.add("hidden");
    document.getElementById("pdf-reader-container").innerHTML = "";
    if (currentBlobUrl) {
        URL.revokeObjectURL(currentBlobUrl);
        currentBlobUrl = null;
    }
    stopSpeech();
}

function speakSummary() {
    if (!activeBook) return;
    stopSpeech();
    const textToRead = `${activeBook.title}, karya ${activeBook.author}. Rangkuman buku: ${activeBook.summary}`;
    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = "id-ID";
    utterance.rate = 0.95;
    window.speechSynthesis.speak(utterance);
}

function stopSpeech() {
    if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
    }
}

function saveLiteracyNote() {
    const note = document.getElementById("literacy-note").value.trim();
    if (!note) {
        document.getElementById("literacy-status").textContent = "Kolom masih kosong (pengisian tidak wajib).";
        return;
    }
    if (currentUser && activeBook) {
        const entry = {
            time: new Date().toLocaleString("id-ID"),
            name: currentUser.name,
            userClass: currentUser.userClass,
            bookTitle: activeBook.title,
            note: note
        };
        literacyNotes.unshift(entry);
        saveLocalData();

        if (CLOUD_API_URL) {
            fetch(CLOUD_API_URL, {
                method: "POST",
                body: JSON.stringify({ action: "addLiteracy", literacy: entry })
            }).catch(() => {});
        }

        document.getElementById("literacy-note").value = "";
        document.getElementById("literacy-status").textContent = "Hasil literasimu berhasil tersimpan!";
    }
}

// ================= FITUR ADMIN: UPLOAD SAMPUL & PDF =================
document.getElementById("add-book-form").addEventListener("submit", async function(e) {
    e.preventDefault();

    const pdfLink = document.getElementById("book-pdf-link").value.trim();
    const extractedId = extractDriveFileId(pdfLink);

    if (!extractedId && !uploadedPdfBase64) {
        alert("Silakan pilih file PDF dari komputer/HP Anda ATAU tempel link file PDF Google Drive!");
        return;
    }

    const btn = document.getElementById("btn-save-book");
    btn.textContent = "Menyimpan & Menyinkronkan...";
    btn.disabled = true;

    const newBook = {
        id: "bk-" + Date.now(),
        title: document.getElementById("book-title").value.trim(),
        author: document.getElementById("book-author").value.trim(),
        category: document.getElementById("book-category").value,
        cover: uploadedCoverBase64,
        summary: document.getElementById("book-summary").value.trim(),
        pdfId: extractedId,
        pdfBase64: uploadedPdfBase64,
        gformUrl: document.getElementById("book-gform").value.trim()
    };

    books.unshift(newBook);
    saveLocalData();

    if (CLOUD_API_URL) {
        try {
            await fetch(CLOUD_API_URL, {
                method: "POST",
                body: JSON.stringify({ action: "addBook", book: newBook })
            });
            await syncFromCloud();
        } catch (err) {
            console.error("Gagal sinkron cloud:", err);
        }
    }

    this.reset();
    uploadedCoverBase64 = "";
    uploadedPdfBase64 = "";
    document.getElementById("cover-preview").classList.add("hidden");
    btn.textContent = "+ Upload & Sinkronkan Buku PDF";
    btn.disabled = false;

    renderAdminTables();
    alert("Buku PDF berhasil ditambahkan! Silakan cek di halaman siswa.");
});

async function deleteBook(id) {
    if (!confirm("Hapus buku ini dari daftar?")) return;
    books = books.filter(b => b.id !== id);
    saveLocalData();
    if (CLOUD_API_URL) {
        fetch(CLOUD_API_URL, {
            method: "POST",
            body: JSON.stringify({ action: "deleteBook", id: id })
        }).catch(() => {});
    }
    renderAdminTables();
}

function renderAdminTables() {
    updateCounters();
    const bookTbody = document.querySelector("#admin-books-table tbody");
    bookTbody.innerHTML = books.map(b => `
        <tr>
            <td>${b.cover ? `<img src="${b.cover}" class="thumb-table">` : "-"}</td>
            <td><strong>${b.title}</strong></td>
            <td>${b.category}</td>
            <td>${b.author}</td>
            <td><button type="button" onclick="deleteBook('${b.id}')" class="btn btn-sm btn-outline" style="color:#B91C1C;border-color:#B91C1C;">Hapus</button></td>
        </tr>
    `).join("");

    const litTbody = document.querySelector("#admin-literacy-table tbody");
    litTbody.innerHTML = literacyNotes.map(l => `
        <tr>
            <td>${l.time}</td>
            <td><strong>${l.name}</strong></td>
            <td>${l.userClass}</td>
            <td>${l.bookTitle}</td>
            <td>${l.note}</td>
        </tr>
    `).join("");

    const visitTbody = document.querySelector("#admin-visits-table tbody");
    visitTbody.innerHTML = visits.map(v => `
        <tr>
            <td>${v.time}</td>
            <td>${v.name}</td>
            <td>${v.userClass}</td>
            <td>${v.activity}</td>
        </tr>
    `).join("");
}

function downloadCSV(filename, rows) {
    const csvContent = "\uFEFF" + rows.map(e => e.join(";")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function exportBooksCSV() {
    const rows = [["ID", "Judul Buku", "Pengarang", "Kategori", "Ringkasan", "ID File PDF"]];
    books.forEach(b => rows.push([
        b.id,
        `"${b.title.replace(/"/g, '""')}"`,
        `"${b.author.replace(/"/g, '""')}"`,
        b.category,
        `"${b.summary.replace(/"/g, '""')}"`,
        b.pdfId || "-"
    ]));
    downloadCSV("Data_Buku_MI_Izzul_Islam.csv", rows);
}

function exportLiteracyCSV() {
    const rows = [["Waktu", "Nama Siswa", "Kelas", "Judul Buku", "Hasil Literasi Siswa"]];
    literacyNotes.forEach(l => rows.push([
        `"${l.time}"`,
        `"${l.name.replace(/"/g, '""')}"`,
        `"${l.userClass}"`,
        `"${l.bookTitle.replace(/"/g, '""')}"`,
        `"${l.note.replace(/"/g, '""')}"`
    ]));
    downloadCSV("Excel_Hasil_Literasi_Siswa_MI_Izzul_Islam.csv", rows);
}

function exportVisitsCSV() {
    const rows = [["Waktu", "Nama Siswa/Guru", "Kelas", "Aktivitas"]];
    visits.forEach(v => rows.push([
        `"${v.time}"`,
        `"${v.name.replace(/"/g, '""')}"`,
        `"${v.userClass}"`,
        `"${v.activity.replace(/"/g, '""')}"`
    ]));
    downloadCSV("Data_Kunjungan_MI_Izzul_Islam.csv", rows);
}

syncFromCloud();